package com.example.mongodb;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/profile")
public class Controller {
	
	@Autowired
	Servicee servicee;
	
	@GetMapping("/ping")
	public ResponseEntity<String> msg()   
	{  
	return new ResponseEntity<String>("Welcome to Profile Page",HttpStatus.OK);  
	}  
	
	@GetMapping("/view")
	private ResponseEntity<List<User>> getAllUser()   
	{  
	return new ResponseEntity<>(servicee.getAllUser(),HttpStatus.OK);  
	}  
	
//	private List<User> getAllUser()   
//	{  
//	return servicee.getAllUser();  
//	}  

	@GetMapping("/view/{id}")  
	private ResponseEntity<User> getUser(@PathVariable("id") Integer id)   
	{  	
		return new ResponseEntity<>(servicee.getUserById(id),HttpStatus.FOUND);  
	} 
	
//	private User getUser(@PathVariable("id") Integer id)   
//	{  
//	return servicee.getUserById(id);  
//	}  
	
	
	@PutMapping("/update/{id}")
	public User updateUser(@RequestBody User user, @PathVariable("id") Integer id)
	{
		return servicee.updateUser(id, user);
	}

}



