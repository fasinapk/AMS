package com.example.mongodb;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/profile")
public class Controller {
	
	@Autowired
	Servicee servicee;
	
	@GetMapping("/ping")
	public String msg()   
	{  
	return "Welcome to Profile Page";  
	}  
	
	@GetMapping("/view")
	private List<User> getAllUser()   
	{  
	return servicee.getAllUser();  
	}  
	
	@GetMapping("/view/{id}")  
	private User getUser(@PathVariable("id") int id)   
	{  
	return servicee.getUserById(id);  
	}  

}























//@PutMapping("/update/{id}")
//public User updateUser(@RequestBody User user, @PathVariable("id") Integer id)
//{
//	return servicee.updateUser(id, user);
//}
