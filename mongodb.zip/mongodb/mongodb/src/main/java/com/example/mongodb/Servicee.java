package com.example.mongodb;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class Servicee {

	@Autowired
	Repo repositoryy;
	
	public List<User> getAllUser()   
	{  
	List<User> users = new ArrayList<User>();  
	repositoryy.findAll().forEach(user -> users.add(user));  
	return users;  
	}  
	
	public User getUserById(int id)   
	{  
	return repositoryy.findById(id).get();  
	}  
	
	
	
	public User updateUser(Integer id, User user)
	{
		Optional<User> findById  = repositoryy.findById(id);
		if(findById.isPresent())
		{
			User userEntity = findById.get();
			
//			if(user.getName() != null && !user.getName().isEmpty())
//			{
//				userEntity.setName(user.getName());
//			}
			if(user.getAge() !=null)
			{
				userEntity.setAge(user.getAge());
			}
			if(user.getEmail() != null)
			{
				userEntity.setEmail(user.getEmail());
			}
			repositoryy.save(userEntity);
		}
		return null;
	}
	
}




