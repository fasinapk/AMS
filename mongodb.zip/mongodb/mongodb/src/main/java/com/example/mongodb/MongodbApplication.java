package com.example.mongodb;


import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;




@SpringBootApplication
public class MongodbApplication implements CommandLineRunner{

	
	@Autowired
	Repo repo;
	
	public static void main(String[] args) {
		SpringApplication.run(MongodbApplication.class, args);
	}
	

	@Override
	public void run(String... args) throws Exception {
		

	
		System.out.println("Embedded mongodb");
		
		repo.insert(new User(1,"aaa",22,"vhjjjjj"));
		repo.insert(new User(2,"bbaa",27,"nkjjjj"));
		repo.insert(new User(3,"ccc",21,"cccc"));
		
		List<User> u=repo.findAll();
	
		
		Iterator<User> itr=u.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next().toString());
		}
		
		System.out.println("inserted");
		
	}
	
	
}
