package com.ust.ams.userprofile.Controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.ust.ams.userprofile.Entity.Profile;
import com.ust.ams.userprofile.Service.ProfileService;

@RestController
@RequestMapping("ams")
public class ProfileController {
	
	
	@Autowired
	ProfileService service;
	
	@GetMapping("/ping")
	public String msg()   
	{  
	return ("Welcome to Profile Page");  
	}  
	
	@GetMapping("/profiles") 
	private List<Profile> getAllProfile()   
	{  
	return service.getAllProfile();  
	}  

	@GetMapping("/profile/{id}")  
	private Profile getProfile(@PathVariable("id") int id)   
	{  
	return service.getProfileById(id);  
	}  
	
	@PutMapping("/profile/{id}")
	public Profile updateUser(@Valid @RequestBody Profile profile, @PathVariable("id") int id)
	{
		return service.updateProfile(id, profile);
	}

}
