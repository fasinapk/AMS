package com.ust.ams.userprofile.Entity;


import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.validation.annotation.Validated;


@Document
@Validated
public class Profile {
	
	@Id
	private int id;
	
	private String name;
	
	@NotNull(message = "Age is mandatory to fill !!")
	private Integer age;
	
	@NotNull(message = "Address is mandatory to fill !!")
	private String adress;
	
	@NotNull
	private String city;
	
	@NotNull
	private String country;
	
	@NotNull
	private String state;
	
	@NotNull
	private Integer zip;
	
	private String role;
	
	@NotNull
	private String email;
	
	@NotNull
	private String phone_no;

	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getAdress() {
		return adress;
	}
	public void setAdress(String adress) {
		this.adress = adress;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Integer getZip() {
		return zip;
	}
	public void setZip(Integer zip) {
		this.zip = zip;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}
	
	@Override
	public String toString() {
		return "Profile [id=" + id + ", name=" + name + ", age=" + age + ", adress=" + adress + ", city=" + city
				+ ", country=" + country + ", state=" + state + ", zip=" + zip + ", role=" + role + ", email=" + email
				+ ", phone_no=" + phone_no + "]";
	}
	public Profile(int id, String name, Integer age, String adress, String city, String country, String state, Integer zip,
			String role, String email, String phone_no) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.adress = adress;
		this.city = city;
		this.country = country;
		this.state = state;
		this.zip = zip;
		this.role = role;
		this.email = email;
		this.phone_no = phone_no;
		
	}
	public Profile() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	

}
