package com.example.project.ams;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Servicee {

	@Autowired
	Repository repositoryy;
	
	public List<Profile> getAllProfile()   
	{  
	List<Profile> profiles = new ArrayList<Profile>();  
	repositoryy.findAll().forEach(profile -> profiles.add(profile));  
	return profiles;  
	}  
	
	public Profile getProfileById(int id)   
	{  
	return repositoryy.findById(id).get();  
	}  
	
	public void save(Profile profile)   
	{  
	repositoryy.save(profile);  
	}  
	
}
