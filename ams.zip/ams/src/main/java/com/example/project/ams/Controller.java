package com.example.project.ams;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController

public class Controller {
	
	@Autowired
	Servicee servicee;
	
	@GetMapping("/ping")
	public String msg()   
	{  
	return "Welcome to Profile Page";  
	}  
	
	@GetMapping("/view")
	private List<Profile> getAllProfile()   
	{  
	return servicee.getAllProfile();  
	}  
	
	@GetMapping("/view/{id}")  
	private Profile getProfile(@PathVariable("id") int id)   
	{  
	return servicee.getProfileById(id);  
	}  
	
	@PostMapping("/save")  
	private int saveProfile(@RequestBody Profile profile)   
	{  
	servicee.save(profile);  
	return profile.getId();  
	}  
	

}
