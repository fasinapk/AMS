package com.example.project.ams;

import org.springframework.data.jpa.repository.JpaRepository;


public interface Repository extends JpaRepository<Profile, Integer>  
{  
}  
