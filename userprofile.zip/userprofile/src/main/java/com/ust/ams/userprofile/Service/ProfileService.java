package com.ust.ams.userprofile.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.ams.userprofile.Entity.Profile;
import com.ust.ams.userprofile.Repository.ProfileRepository;


@Service
public class ProfileService {

	
	@Autowired
	ProfileRepository repository;
	
	public List<Profile> getAllProfile()   
	{  
	List<Profile> profiles = new ArrayList<Profile>();  
	repository.findAll().forEach(profile -> profiles.add(profile));  
	return profiles;  
	}  
	
	public Profile getProfileById(int id)   
	{  
	return repository.findById(id).get();  
	}  
	
	public Profile updateProfile(Integer id, Profile profile)
	{
		Optional<Profile> findById  = repository.findById(id);
		if(findById.isPresent())
		{
			Profile profileEntity = findById.get();
			
			if(profile.getName() != null && !profile.getName().isEmpty())
			{
				profileEntity.setName(profile.getName());
			}
			if(profile.getAge() !=null)
			{
				profileEntity.setAge(profile.getAge());
			}
			if(profile.getAdress() != null)
			{
				profileEntity.setAdress(profile.getAdress());
			}
			if(profile.getCity() != null)
			{
				profileEntity.setCity(profile.getCity());
			}
			if(profile.getCountry() != null)
			{
				profileEntity.setCountry(profile.getCountry());
			}
			if(profile.getState() != null)
			{
				profileEntity.setState(profile.getState());
			}
			if(profile.getZip() != null)
			{
				profileEntity.setZip(profile.getZip());
			}
			if(profile.getEmail() != null)
			{
				profileEntity.setEmail(profile.getEmail());
			}
			if(profile.getPhone_no() != null)
			{
				profileEntity.setPhone_no(profile.getPhone_no());
			}
			if(profile.getPhone_code() != null)
			{
				profileEntity.setPhone_code(profile.getPhone_code());
			}
			repository.save(profileEntity);
		}
		return null;
	}
}
