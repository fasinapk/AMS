package com.ust.ams.userprofile;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.ust.ams.userprofile.Entity.Profile;
import com.ust.ams.userprofile.Repository.ProfileRepository;


@SpringBootApplication
public class UserprofileApplication implements CommandLineRunner {

	
	@Autowired
	ProfileRepository repo;
	public static void main(String[] args) {
		SpringApplication.run(UserprofileApplication.class, args);
		
		
		
	}
	
	@Override
	public void run(String... args) throws Exception {
		

	
		System.out.println("Embedded mongodb");
		
		repo.insert(new Profile(1,"Fasina",24,"behdbgsag","kerajkdj","dnjdn","dbjbjadm",123456,"user123","pkfasina@gmail.com",965632456,91));
		repo.insert(new Profile(2,"Anju",23,"behdbgsag","kerajkdj","dnjdn","dbjbjadm",123456,"user123","anju@gmail.com",965665456,91));
		repo.insert(new Profile(3,"Arun",24,"behdbgsag","kerajkdj","dnjdn","dbjbjadm",123456,"user123","arun@gmail.com",965645656,91));
		
		List<Profile> u=repo.findAll();
	
		
		Iterator<Profile> itr=u.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next().toString());
		}
		
		System.out.println("inserted");
		
	}
	
	

}
